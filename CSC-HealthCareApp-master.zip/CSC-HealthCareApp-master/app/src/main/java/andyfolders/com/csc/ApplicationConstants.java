package andyfolders.com.csc;

/**
 * Created by Lokkeshwaran J on 18-11-2015.
 */
public interface ApplicationConstants {
    // Php Application URL to store Reg ID created


    // Google Project Number
    static final String GOOGLE_PROJ_ID = "174007249838";
    static final String MSG_KEY = "m";
}
